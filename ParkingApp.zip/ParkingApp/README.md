# ParkingAppUI
## Overview

<p float="left">
<img src="https://github.com/kazimunshimun/ParkingAppUI/raw/main/parking_animation.gif" width="340">
</p>

#### Tutorial:

[![Parking app UI Tutorial](http://img.youtube.com/vi/QkRIfAv9nlk/0.jpg)](https://youtu.be/QkRIfAv9nlk)

#### Dribble Design Inspiration: https://dribbble.com/shots/14408667-Parking-Space-Finder-Concept
